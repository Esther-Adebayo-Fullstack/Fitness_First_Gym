# gym/signals.py

from django.db.models.signals import post_migrate, post_save
from django.dispatch import receiver
from .models import Trainer
from django.contrib.auth.models import User
from authapp.models import Booking, UserProfile


# Signal receiver to create a UserProfile when a new User is created
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)


# Signal receiver to save the UserProfile when a User is saved
@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.userprofile.save()


# Signal receiver to create or update the UserProfile when a Booking is created
@receiver(post_save, sender=Booking)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        # Create or update the user profile with the booking address
        UserProfile.objects.update_or_create(
            user=instance.user,
            defaults={
                'address': instance.address,
                'full_name': instance.fullname,
                'phone_number': instance.phone_number
            }
        )


# Signal receiver to create default trainers after migrations are done
@receiver(post_migrate)
def create_default_trainers(sender, **kwargs):
    # Check if the migration sender is 'authapp' (your app name)
    if sender.name == 'authapp':
        # Define a list of default trainers with their details
        trainers = [
            {'name': 'Patrick Cortez', 'email': 'Cortz@mail.com', 'age': 26, 'img': 'Patrick Cortez.jpg'},
            {'name': 'Jordan Syatt', 'email': 'Syatt125@gmail.com', 'age': 36, 'img': 'Jordan Syatt.jpg'},
            {'name': 'Monica Swatt', 'email': 'monique@gmail.com', 'age': 30, 'img': 'Monica Swatt.jpg'},
            {'name': 'Rocco Terry', 'email': 'terrymight@gmail.com', 'age': 40, 'img': 'Rocco Terry.jpeg'},
            {'name': 'Terry Malam', 'email': 'lamma3@gmail.com', 'age': 25, 'img': 'Terry Malam.jpeg'},
            {'name': 'Olivia Jones', 'email': 'jonees@gmail.com', 'age': 25, 'img': 'Olivia Jones.jpg'},
        ]

        # Create or get each trainer object from the list and set default values
        for trainer in trainers:
            Trainer.objects.get_or_create(name=trainer['name'], defaults=trainer)
