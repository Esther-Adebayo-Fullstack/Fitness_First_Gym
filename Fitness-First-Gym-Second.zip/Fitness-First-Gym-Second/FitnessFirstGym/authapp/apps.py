from django.apps import AppConfig

class AuthappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'  # Specifies the default auto field for models
    name = 'authapp'  # Specifies the name of the Django application


from django.apps import AppConfig

class AuthappConfig(AppConfig):
    name = 'authapp'  # Specifies the name of the Django application

    def ready(self):
        """
        Method called when Django starts.
        Imports signals module to register signal handlers.
        """
        import authapp.signals  # Importing signals module to register signals
