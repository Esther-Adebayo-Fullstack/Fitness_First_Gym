from django.shortcuts import render
from django.shortcuts import render, redirect
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from authapp.models import Contact, Trainer, MembershipPlan, Booking, UserProfile, Facility, Subscribe
from django.db.models.signals import post_migrate, post_save
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from .models import UserProfile
from .forms import UserProfileForm
from datetime import datetime
from decimal import Decimal


# Home view - Renders the home page with trainers and membership plans
def Home(request):
    # Fetch all trainers and membership plans from database
    trainer = Trainer.objects.all()[:3] # Fetch first 3 trainers
    membership = MembershipPlan.objects.all()
    
    # Prepare context data to be sent to the template
    context ={
        "trainer": trainer,
        "membership_plans": membership
    }
    
    # Render the 'index.html' template with context data
    return render(request, "index.html", context)


# Profile view - Handles user profile display and update
@login_required
def profile(request):
    # Get or create user profile for the logged-in user
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    
    # Retrieve bookings associated with the current user
    bookings = Booking.objects.filter(user=request.user)
    
    if request.method == 'POST':
        # If form is submitted, process the form data
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            # Save the form data if valid
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')  # Redirect to profile page after successful update
        else:
            # Display error messages if form is invalid
            messages.error(request, 'Error updating profile. Please correct the errors.')
    else:
        # If GET request, display the profile form with current user's data
        form = UserProfileForm(instance=user_profile)

    # Prepare context data to be sent to the template
    context = {
        'form': form,
        'user_profile': user_profile,
        'bookings': bookings  # Add bookings to context
    }
    
    # Render the 'profile.html' template with context data
    return render(request, 'profile.html', context)


# Update profile view - Handles updating user profile information
@login_required
def update_profile(request):
    # Get or create user profile for the logged-in user
    user_profile = UserProfile.objects.get_or_create(user=request.user)[0]

    if request.method == 'POST':
        # If form is submitted, process the form data
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            # Save the form data if valid
            form.save()
            return redirect('profile')  # Redirect to profile page after successful update
    else:
        # If GET request, display the profile update form with current user's data
        form = UserProfileForm(instance=user_profile)

    # Prepare context data to be sent to the template
    context = {
        'form': form
    }
    
    # Render the 'profile_update.html' template with context data
    return render(request, 'profile_update.html', context)


# User sign up view - Handles new user registration
def signUp(request):
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirmPassword = request.POST.get('confirmPassword')

        try:
            # Check if username already exists
            user = User.objects.get(username=username)
            if user:
                messages.error(request, "Username already exists")
                return redirect("/signUp")
        except User.DoesNotExist:
            pass 

        try:
            # Check if email already exists
            user = User.objects.get(email=email)
            if user:
                messages.error(request, "Email already exists")
                return redirect("/signUp")
        except User.DoesNotExist:
            pass 

        if password != confirmPassword:
            # Display error if passwords do not match
            messages.warning(request, "Passwords do not match")
            return redirect("/signUp")
        
        # Create new user with provided username, email, and password
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()

        # Check if a user profile already exists; if not, create one
        if not UserProfile.objects.filter(user=user).exists():
            user_profile = UserProfile(user=user)
            user_profile.date_joined = datetime.now().date()  # Capture the current date
            user_profile.save()

        # Display success message and redirect to login page
        messages.success(request, "Registration successful! You can now log in.")
        return redirect("/login")
       
    # Render the 'signUp.html' template for GET requests
    return render(request, "signUp.html")


# User login view - Handles user authentication and login
def Login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        # Authenticate user credentials
        myuser = authenticate(username=username, password=password)

        if myuser is not None:
            # If authentication is successful, log the user in
            login(request, myuser)
            return redirect("/")  # Redirect to home page after login
        else:
            # Display error message for invalid credentials
            messages.error(request, "Invalid Credentials")
    
    # Render the 'Login.html' template for GET requests
    return render(request, "Login.html")


# User logout view - Handles user logout
def Logout(request):
    logout(request)  # Log out the current user
    messages.info(request, "Logout Successful")  # Display logout success message
    return redirect('/login')  # Redirect to login page after logout

def subscribe(request):
    if request.method == "POST":
        email = request.POST.get('email')
        myquery = Subscribe(name=email)
        myquery.save()
        return redirect('/thanks')
   
def thanks(request):

    return render(request, "thanks.html")
# About view - Renders the about page with trainers and membership plans
def About(request):
    trainer = Trainer.objects.all()
    membership = MembershipPlan.objects.all()  # Fetch all membership plans
    
    # Prepare context data to be sent to the template
    context ={
        "trainer": trainer,
        "membership_plans": membership
    }
    
    # Render the 'about.html' template with context data
    return render(request, "about.html", context)


# Classes view - Renders the classes page
def Classes(request):
    # Render the 'classes.html' template
    return render(request, "classes.html")


# Facilities view - Renders the facilities page with all facilities
def facilities(request):
    facilities = Facility.objects.all()  # Fetch all facilities
    
    # Prepare context data to be sent to the template
    return render(request, 'facilities.html', {'facilities': facilities})


# Profile view (alternative implementation) - Handles displaying and updating user profile
@login_required
def profile_view(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
        else:
            messages.error(request, 'Error updating profile. Please correct the errors.')
    else:
        form = UserProfileForm(instance=user_profile)

    context = {
        'form': form,
        'user_profile': user_profile
    }
    
    # Render the 'profile.html' template with context data
    return render(request, 'profile.html', context)


# Blog view - Renders the blog page
def blog(request):
    # Render the 'blog.html' template
    return render(request, 'blog.html')


# Gallery view - Renders the gallery page
def gallery(request):
    # Render the 'gallery.html' template
    return render(request, 'gallery.html')


# Contact view - Handles user contact form submission
def contact(request):
    if request.method == "POST":
        name = request.POST.get('fullname')
        email = request.POST.get('email')
        phonenumber = request.POST.get('phonenumber')
        desc = request.POST.get('desc')

        # Create a new Contact object and save it to the database
        myquery = Contact(name=name, email=email, phonenumber=phonenumber, description=desc)
        myquery.save()
        
        # Redirect to home page after successful form submission
        return redirect("/thanks")
    
    # Render the 'contact.html' template for GET requests
    return render(request, "contact.html")


# Booking view - Handles user booking form submission
def booking(request):
    if not request.user.is_authenticated:
        # Redirect to login page if user is not authenticated
        messages.info(request, 'Please login and try again.')
        return redirect('/login')

    # Fetch all trainers and membership plans from database
    trainers = Trainer.objects.all()
    membership_plans = MembershipPlan.objects.all()

    if request.method == "POST":
        # Fetch form data submitted via POST request
        fullname = request.POST.get('fullname')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        membership_name = request.POST.get('membership')
        trainer_name = request.POST.get('trainer')
        reference = request.POST.get('reference')
        address = request.POST.get('address')
        price = Decimal(request.POST.get('price', 0))  # Convert to Decimal

        # Fetch membership plan and trainer objects based on form data
        try:
            membership_plan = MembershipPlan.objects.get(name=membership_name)
        except MembershipPlan.DoesNotExist:
            membership_plan = None

        try:
            trainer = Trainer.objects.get(name=trainer_name)
        except Trainer.DoesNotExist:
            trainer = None
        
        # Determine payment status based on price and membership plan price
        if membership_plan and price < membership_plan.price:
            payment_status = 'Partial'
        elif membership_plan and price == membership_plan.price:
            payment_status = 'Full'
        else:
            payment_status = 'Unknown'

        # Validate price against membership plan price
        if membership_plan and price <= membership_plan.price:
            # Create a new Booking object and save it to the database
            book = Booking(
                fullname=fullname,
                email=email,
                phone_number=phone_number,
                gender=gender,
                dob=dob,
                user=request.user,
                select_membership=membership_plan,
                select_trainer=trainer,
                reference=reference,
                address=address,
                price=price,
                payment_status=payment_status
            )
            book.save()

            # Display success message and redirect to booking page
            messages.success(request, 'Booking successfully created!')
            return redirect('/booking')
        else:
            # Display error message if price exceeds membership plan price
            messages.error(request, "Price cannot be greater than membership price")
            return redirect('/booking')

    # Prepare context data to be sent to the template
    context = {
        "trainers": trainers,
        "membership_plans": membership_plans
    }
   
    # Render the 'booking.html' template with context data
    return render(request, "booking.html", context)


# Signal receiver function to update user profile after booking creation
@receiver(post_save, sender=Booking)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        # Create or update the user profile with booking details
        UserProfile.objects.update_or_create(
            user=instance.user,
            defaults={
                'address': instance.address,
                'full_name': instance.fullname,
                'phone_number': instance.phone_number
            }
        )


# Staff member restricted view to generate reports
@staff_member_required
def reportView(request):
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')
    
    bookings = []
    users = []
    
    if start_date and end_date:
        # Convert start_date and end_date strings to datetime objects
        start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
        
        # Fetch bookings and users within the specified date range
        bookings = Booking.objects.filter(date_enrolled__range=[start_date, end_date])
        users = User.objects.filter(date_joined__range=[start_date, end_date])
        
        # Prepare context data to be sent to the template
        context = {
            'bookings': bookings,
            'users': users,
            'start_date': start_date,
            'end_date': end_date
        }
        
        # Render the 'report.html' template with context data
        return render(request, 'report.html', context)
    else:
        # Render the 'report_form.html' template if start_date and end_date are not provided
        return render(request, 'report_form.html')
