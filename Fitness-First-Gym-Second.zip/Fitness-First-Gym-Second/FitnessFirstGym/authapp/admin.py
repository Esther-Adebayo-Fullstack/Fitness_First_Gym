from django.contrib import admin
from authapp.models import Contact,Category, PackageType, Package,MembershipPlan, Booking, Trainer, Facility, Subscribe

# Register your models here.

admin.site.register(Contact)

admin.site.register(Category)
admin.site.register(PackageType)
admin.site.register(Package)
admin.site.register(MembershipPlan)
admin.site.register(Booking)
admin.site.register(Trainer)
admin.site.register(Facility)
admin.site.register(Subscribe)



