from django.db import models
from django.contrib.auth.models import User
from django import forms



class Subscribe(models.Model):
    name = models.EmailField()
    
    def __str__(self):
        return self.name

# Function to define upload path for user profile pictures
def user_directory_path(instance, filename):
    """
    Generates file upload path for UserProfile profile_picture field.
    Files will be uploaded to MEDIA_ROOT/user_<id>/<filename>.
    """
    return f'user_{instance.user.id}/{filename}'

# UserProfile model
class UserProfile(models.Model):
    """
    Extends Django User model with additional profile information.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=255)  # Full name of the user
    phone_number = models.CharField(max_length=15)  # Contact phone number
    about_user = models.TextField()  # Personal description of the user
    address = models.TextField()  # User's address
    profile_picture = models.ImageField(upload_to=user_directory_path, blank=True, null=True)  # User's profile picture
    date_joined = models.DateField(auto_now_add=True, blank=True, null=True)  # Date user joined

    def __str__(self):
        return self.user.username  # String representation of the UserProfile instance

# Form to update UserProfile
class UserProfileForm(forms.ModelForm):
    """
    Form for updating UserProfile model.
    """
    class Meta:
        model = UserProfile
        fields = ['full_name', 'phone_number', 'about_user', 'address', 'profile_picture']

# Contact model
class Contact(models.Model):
    """
    Stores contact information submitted via website contact form.
    """
    name = models.CharField(max_length=25)  # Name of the contact person
    email = models.EmailField()  # Email address of the contact person
    phonenumber = models.CharField(max_length=11)  # Contact phone number
    description = models.TextField()  # Message or description from the contact person

    def __str__(self):
        return self.email  # String representation of the Contact instance

# Category model
class Category(models.Model):
    """
    Represents categories that can be assigned to different packages.
    """
    name = models.CharField(max_length=255)  # Name of the category

    def __str__(self):
        return self.name  # String representation of the Category instance

# MembershipPlan model
class MembershipPlan(models.Model):
    """
    Defines various membership plans available at the gym.
    """
    name = models.CharField(max_length=255)  # Name of the membership plan
    duration = models.CharField(max_length=50, blank=True)  # Duration of the membership plan
    price = models.DecimalField(max_digits=6, decimal_places=1, null=True)  # Price of the membership plan
    price_unit = models.CharField(max_length=10, default='MONTH')  # Unit of the price (e.g., month, year)
    unlimited_access = models.CharField(max_length=255, blank=True)  # Description of unlimited access features
    classes_per_week = models.IntegerField(null=True, blank=True)  # Number of classes per week
    drinking_package = models.BooleanField(default=False)  # Whether drinking package is included
    personal_trainer = models.BooleanField(default=False)  # Whether personal trainer is included

    def __str__(self):
        return self.name  # String representation of the MembershipPlan instance

# PackageType model
class PackageType(models.Model):
    """
    Specifies types of packages offered at the gym.
    """
    name = models.CharField(max_length=255)  # Name of the package type

    def __str__(self):
        return self.name  # String representation of the PackageType instance

# Trainer model
class Trainer(models.Model):
    """
    Represents trainers employed by the gym.
    """
    name = models.CharField(max_length=255)  # Name of the trainer
    email = models.EmailField()  # Email address of the trainer
    expertise = models.ForeignKey(PackageType, on_delete=models.CASCADE, blank=True, null=True)  # Trainer's expertise (linked to PackageType)
    age = models.IntegerField()  # Age of the trainer
    image = models.ImageField(upload_to="trainer_images/", null=True, blank=True)  # Trainer's profile image

    def __str__(self):
        return self.name  # String representation of the Trainer instance

# Package model
class Package(models.Model):
    """
    Describes different packages available at the gym.
    """
    description = models.TextField()  # Description of the package
    additional = models.TextField(blank=True)  # Additional information about the package
    duration_in_num = models.DecimalField(max_digits=3, decimal_places=1, null=True)  # Duration of the package in numerical form
    duration = models.CharField(max_length=50)  # Duration unit (e.g., hours) of the package
    category = models.ForeignKey(Category, on_delete=models.CASCADE)  # Category of the package (linked to Category model)
    package_type = models.ForeignKey(PackageType, on_delete=models.CASCADE)  # Type of the package (linked to PackageType model)

    def __str__(self):
        return f'{self.package_type.name} - {self.category.name}'  # String representation of the Package instance

# Booking model
class Booking(models.Model):
    """
    Stores details of bookings made by users.
    """
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other'),
    ]
    
    PAYMENT_STATUS_CHOICES = [
        ('Partial', 'Partial'),
        ('Full', 'Completed'),
    ]

    fullname = models.CharField(max_length=25)  # Full name of the booking person
    email = models.EmailField()  # Email address of the booking person
    gender = models.CharField(max_length=6, choices=GENDER_CHOICES)  # Gender of the booking person
    phone_number = models.CharField(max_length=15)  # Contact phone number of the booking person
    dob = models.DateField()  # Date of birth of the booking person
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # User who made the booking (linked to User model)
    select_membership = models.ForeignKey(MembershipPlan, on_delete=models.CASCADE, null=True)  # Selected membership plan (linked to MembershipPlan model)
    select_package = models.ForeignKey(Package, on_delete=models.CASCADE, null=True)  # Selected package (linked to Package model)
    select_trainer = models.ForeignKey(Trainer, on_delete=models.CASCADE, null=True)  # Selected trainer (linked to Trainer model)
    reference = models.CharField(max_length=55)  # Reference information for the booking
    address = models.TextField()  # Address of the booking person
    payment_status = models.CharField(max_length=10, choices=PAYMENT_STATUS_CHOICES, blank=True, null=True)  # Payment status of the booking
    price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)  # Price of the booking
    due_date = models.DateTimeField(blank=True, null=True)  # Due date for payment
    date_enrolled = models.DateTimeField(auto_now_add=True)  # Date when the booking was made

    def __str__(self):
        return self.fullname  # String representation of the Booking instance

# Facility model
class Facility(models.Model):
    """
    Represents facilities available at the gym.
    """
    name = models.CharField(max_length=255)  # Name of the facility
    description = models.TextField()  # Description of the facility
    image = models.ImageField(upload_to='facilities/')  # Image of the facility

    def __str__(self):
        return self.name  # String representation of the Facility instance
